# Cours CSS

## CSS qu'est ce que c'est ?

- C.S.S. : Cascading Style Sheet (Feuille de style en cascade).
- Corrige les lacunes de mise en forme du HTML.

## Plusieurs niveaux de CSS

1. Feuille de style du navigateur.
2. Feuille de style Externe.
3. Feuille de style Interne.
4. Feuille de style En Ligne (inline).

Chaque niveau de feuille de style ecrase les propriétés définies dans les feuilles de style de niveau inférieur.

## Extension

Les fichiers CSS possèdent l'extension ".css"
